<?php

$_SESSION["tr"]=true;

echo "<h4 style='text-align:center;color:red'> Your Security Code is Incorrect. Please try again.</h4>";

?>
	
	<form action="resetPass.php" method="post">
	<input type="submit" value="Try Again" style="margin-left:600px"/>
	</form>
	
	<form action="login.php" method="post">
	<input type="submit" value="Exit" style="margin-left:600px"/>
	</form>
	


