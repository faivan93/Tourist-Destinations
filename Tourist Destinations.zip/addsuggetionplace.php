<?php

session_start();

$_SESSION["addsuggetionplace"]=false;

		
	if (isset($_SESSION['loginchk']))
	{
	
		if($_SESSION['loginchk']==true)
		{
			
			$name=$_POST["sname"];
			$location=$_POST["slocation"];
			$description=$_POST["sdesc"];
			$latitude=$_POST["slatitude"];
			$longitude=$_POST["slongitude"];



		$conn = mysqli_connect("localhost", "root", "","project");

		if (!$conn) {
			die("Connection failed: " . mysqli_connect_error());
		}


			$sql='insert into places(name,location,description,latitude,longitude) values("'.$name.'" , "'.$location.'" , "'.$description.'" ,'.$latitude.' ,'.$longitude.')';
			echo $sql;
			$result =mysqli_query($conn, $sql)or die(mysqli_error());
			
			$_SESSION["addsuggetionplace"]=true;
			
			header("Location:admin.php");
			
		}
		else
		{	
		
		
		header("Location:login.php");
		}
	}
	else
	{
		
		header("Location:login.php");
	}


?>