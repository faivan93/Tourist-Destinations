<?php require("mysql-to-json.php"); ?>



<!DOCTYPE html>
<html>




<style>
  html, body {
    height: 100%;
  }
  #tableContainer-1 {
    height: 100%;
    width: 100%;
    display: table;
  }
  #tableContainer-2 {
    vertical-align: middle;
    display: table-cell;
    height: 100%;
  }
  
  #desc {
    vertical-align: middle;
    margin-left:30px;
	margin-right:30px;
	color:black;
    }
  
  #myTable {
    margin: 0 auto;
  }
  
  #map {
       
		
		
	position : absolute;    
    width    : 90%;
    height   : 80%;
   
    margin-left : 70px; /* half of the width  */
    margin-top  : 100px;
      }
</style>






<body>

	

 

<?php
	
	
	
	$place=$_REQUEST['place'];

		$lt=0;
		$lng=0;
		
		
		$lalngsql='select latitude,longitude,description from places where name="'.$place.'";';
		
		$ljson= getJSONFromDB($lalngsql);
		
		$lj=json_decode($ljson,true);
	
		
		
		$lt=$lj[0]["latitude"];
		$lng=$lj[0]["longitude"];
		
		
		$lalngsql2='select description from places where name="'.$place.'";';
		
		$ljson2= getJSONFromDB($lalngsql2);
		
		$lj2=json_decode($ljson2,true);
		
		
		
		$desc=$lj2[0]["description"];
		
		
		$sql= 'SELECT * FROM places_image WHERE locationID=(select locationID from places where name="'.$place.'");';
	
		$jsonData= getJSONFromDB($sql);
			
			
			$jsn=json_decode($jsonData,true);
		$str="";
			for ($i=0;$i<sizeof($jsn);$i++)
			{
	
					$str=$str.'<tr> <td><img src="'.$jsn[$i]["imgURL"].'"width="800" height="455" style="float: center"/></td></tr>';
				
				
			}
			
			echo '<div id="tableContainer-1">  <div id="tableContainer-2">    <table id="myTable" >'.$str.'</table>  </div></div></br></br>';
			
			echo '</br><div id="desc"><h3>'.$desc.'</h3></div>';

?>




<div id="map"></div></br></br>


    <script>	
     
      function initMap() {
        var uluru = {lat:<?php echo $lt;?>, lng: <?php echo $lng;?>};
        var map = new google.maps.Map(document.getElementById('map'), {
          zoom: 12,
          center: uluru
        });
        var marker = new google.maps.Marker({
          position: uluru,
          map: map
        });
      }
    </script>
    
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAd47JVe5tfiZflG1GXVuqjS7gfYl9fmOg&callback=initMap">
    </script>


</body>

	</br></br></br>

</html>