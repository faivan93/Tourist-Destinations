<?php


session_start();

$user=$_SESSION["uemail"];
$_SESSION["userpicadd"]=false;

$loc=$_POST["wgtmsr"];
$caption=$_POST["comments"];
$imgurl=$_FILES["fileToUpload"]["name"];


$conn = mysqli_connect("localhost", "root", "","project");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}




$target_Path = $user."/".$imgurl;
$target_tmp =  $_FILES["fileToUpload"]["tmp_name"] ;

$target_dir = $user."/";
$target_file = $target_dir . $_FILES["fileToUpload"]["name"];
echo $_FILES["fileToUpload"]["name"]."<br>";
$uploadOk = 1;



// Check if image file is a actual image or fake image
if (file_exists($target_file)) {
    echo "Sorry, file already exists<br>";
    $uploadOk = 0;
}
if ($_FILES["fileToUpload"]["size"] > 50000000) {
    echo "File size exceeded<br>";
    $uploadOk = 0;
}
if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded<br>";
}
else{
	require("mysql-to-json.php");
	
	
	
	$so='select locationID from places where name="'.$loc.'";';
	$jsonData= getJSONFromDB($so);

			$jsn=json_decode($jsonData,true);
			$val=$jsn[0]["locationID"];
			echo $val;
	
	
    if(move_uploaded_file( $target_tmp, $target_file))
	{
		$sql='insert into user_image(user_email,image_url,locationID,caption) values("'.$user.'","'.$target_file.'","'.$val.'","'.$caption.'");';
		
		//echo $sql;
		$result =mysqli_query($conn, $sql)or die(mysqli_error());
       // echo "The file ".  $_FILES["fileToUpload"]["name"]. " has been uploaded<br>";
		
		$_SESSION["userpicadd"]=true;
		header("Location:newpicupload.php");
    }
	else 
	{
        echo "Sorry, there was an error uploading your file<br>";
    }
}



?>


