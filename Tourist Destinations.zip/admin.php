<!DOCTYPE html>
<html>
<?php require("mysql-to-json.php"); ?>
<head>


<style>
div.container {
    width: 100%;
    border: 1px solid gray;
}

header, footer {
    padding: .001em;
    color: white;
    background-color: aqua;
    clear: left;
    text-align: center;
	margin-bottom: 15px;
	hight:200px;
}



nav {
    float: center;
    max-width: 450px;
    margin: 0;
    padding: 1em;
}

nav ul {
    list-style-type: none;
    padding: 0;
}
   
nav ul a {
    text-decoration: none;
}

article {
    margin-left: 170px;
    border-left: 0;
    padding: 1em;
    overflow: hidden;
}


div{
	display:inline;
}


.button {
  display: inline-block;
  padding: 10px 20px;
  font-size: 15px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #fff;
  background-color: #4CAF50;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
 
}

.button:hover {background-color: #3e8e41;}

.button:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}


#wgtmsr{
 width:200px;
	hight: 100px ;
	font-size: 17px;
}



</style>

<title>Tourist Destinations of Bangladesh</title> 
</head>



<body >



<header>
	<span style="float:center"><h1 style="float:center;margin-left:150px">Tourist Destinations of Bangladesh <?php

	session_start();
	

	if (isset($_SESSION['loginchk']))
	{
		if($_SESSION['loginchk']==true)
		{
			?>
			<span style="float:right"><input type="button" class="button" onclick="logout()" value="Logout"  style="margin-right:50px">
			</h1>Welcome <?php $user=$_SESSION["adminemail"];
		
			
			

			$jsonData= getJSONFromDB("select * from user_info");

			$jsnu=json_decode($jsonData,true);
		
			for ($i=0;$i<sizeof($jsnu);$i++)
			{
				if($jsnu[$i]["email"]==$user)
				{
					echo $jsnu[$i]["firstName"]." ".$jsnu[$i]["lastName"];
				}
			}
			
		}
		else
		{	
		echo "<h1 style='text-align:center'>You are To Login First</h1></br></br>";
		
		header("Location:login.php");
		}
	}
	else
	{
		echo "<h1 style='text-align:center'>You Need To Login First</h1></br></br>";
		header("Location:login.php");
	}
	?>   

				
	</br></br></h1>
</header>

<?php


		$strl='<select  name="wgtmsr" id="wgtmsr" style="float:center" ><option>Select</option>';
		
			$locdata= getJSONFromDB("select name from places ORDER BY places.name ASC ");

			$ljson=json_decode($locdata,true);
		
			for ($i=0;$i<sizeof($ljson);$i++)
			{
	
				$strl=$strl.'<option value="'.$ljson[$i]["name"].'">'.$ljson[$i]["name"].'</option>';
				
			}
			$strl=$strl."</select>";
?>



<span id="fsp" style="visibility:hidden"><?php echo $strl; ?></span>


<span style="display: block; margin: 0px auto; text-align: center;">
	<input type ="button" id="addimg" onclick="addimage()" class="button" value ="Add Image"></br></br>
	<input type ="button" id="addimg" class="button" onclick="addplace()" value ="Add Place"></br></br>
	<input type ="button" id="seesuggetion" class="button" onclick="seesugg()" value ="See Suggetion"></br></br>
	<input type ="button" id="addimg" class="button"   onclick="updateplace()" value ="Update Place's Information"></br></br>
</span>


<form action="AdminAddImage.php" method="post" enctype="multipart/form-data">

<?php

		

			if(isset($_SESSION["addimgup"]))
			{
				if($_SESSION["addimgup"]==true)
				{
					echo "</br><h4>Image Upload Successfully</h4></br>";
					$_SESSION["addimgup"]=false;
				}
				else
				{
					echo "</br><h4>Sorry, there was an error uploading your file</h4></br>";
					$_SESSION["addimgup"]=false;
				}
			}
			
			
?>

<span id="divimg" style="display:inline-block; margin: 0px auto; width:30%"></span> &nbsp &nbsp


<?php

	

			$locdata= getJSONFromDB("select * from places_image");
			$ljson=json_decode($locdata,true);
			$str2="<table border='1px' width='90%'><tr> <td>Image ID</td><td>Location ID</td></tr>";
			for ($i=0;$i<sizeof($ljson);$i++)
			{
	
					$str2=$str2."<tr> <td>".$ljson[$i]["imageId"]."</td><td>".$ljson[$i]["locationID"]."</td></tr>";
					
				
			}
			$str2=$str2."</table>";	

?>


<span id="image_table" style="display: inline-block; margin: 0px auto;visibility:hidden;width:30%"><?php echo $str2; ?></span>

</form>

<form action="adminaddplace.php" method="post">


<?php

		

			if(isset($_SESSION["plcadd"]))
			{
				if($_SESSION["plcadd"]==true)
				{
					echo "</br><h4>Place Added Successfully</h4></br>";
					$_SESSION["plcadd"]=false;
				}
				else
				{
					echo "</br><h4>Sorry, there was an error to add place</h4></br>";
					$_SESSION["plcadd"]=false;
				}
			}
			
			
?>


<span id="addplace" style="display:inline-block; margin-left: 250px;margin-bottom: 100px; width:50%"></span> &nbsp &nbsp

</form>


<form action="addsuggetionplace.php" method="post">




<?php

		

			if(isset($_SESSION["addsuggetionplace"]))
			{
				if($_SESSION["addsuggetionplace"]==true)
				{
					echo "</br><h4>Place Added Successfully</h4></br>";
					$_SESSION["addsuggetionplace"]=false;
				}
				
			}
			
			
?>

<span id="seesugg" style="display:inline-block; margin: 50px auto; width:30%"></span> &nbsp &nbsp

<?php

			$jsonData3= getJSONFromDB("select * from suggested");

			$js3=json_decode($jsonData3,true);
			$str3="<table border='1px' width='90%'><tr> <td>Name</td><td>Location</td><td>Description</td><td>Latitude</td><td>Longitude</td></tr>";
			for ($i=0;$i<sizeof($js3);$i++)
			{
				$str3=$str3."<tr> <td>".$js3[$i]["name"]."</td><td>".$js3[$i]["location"]."</td><td>".$js3[$i]["description"]."</td><td>".$js3[$i]["latitude"]."</td><td>".$js3[$i]["longitude"]."</td></tr>";			
			}
			$str3=$str3."</table></br></br><input type='button' id='checked' onclick='emptytable()' value='checked'/>";	
?>

<span id="sugg_table" style="display: inline-block; margin: 0px auto;visibility:hidden;width:30%"><?php echo $str3; ?></span>


</form>


<form action="updateplace.php" method="post">

<?php
	if(isset($_SESSION["plcupdate"]))
	{
		if($_SESSION["plcupdate"]==true)
		{
			echo "</br><h4>Place Information Updated Successfully</h4></br>";
			$_SESSION["plcupdate"]=false;
		}
		else
		{
			echo "</br><h4>Sorry, there was an error to update places information</h4></br>";
			$_SESSION["plcupdate"]=false;
		}
	}		
?>


<span id="updateplace" style="display:inline-block; margin-left: 250px;margin-bottom: 100px; width:50%"></span> &nbsp &nbsp

</form>

</body>

</html>



<script type="text/javascript">

	function addimage()
	{
		
		$str=document.getElementById("fsp").innerHTML;
		
		addstr = "<input id='imgid' name='addimgid' required='required' type='text'  placeholder='Image ID' style='font-size:10pt;height:25px;width:250px;' /></br></br></br> "+$str+"</td></br></br></br>  <input type='file' name='fileToUpload' id='fileToUpload'/></br></br></br><input type='submit' id='addsuggestion' value='Upload'/>"
		document.getElementById("divimg").innerHTML=addstr;
	
		document.getElementById("image_table").style.visibility = "visible";
		document.getElementById("divimg").style.visibility ='visible';
		document.getElementById("addplace").style.visibility ='hidden';
		document.getElementById("sugg_table").style.visibility ='hidden';
		document.getElementById("seesugg").style.visibility ='hidden';
		
	}
	
	
	function addplace()
	{
		addstr2 = "<input id='name' name='name' required='required' type='text'  placeholder='Name' style='font-size:10pt;height:25px;width:250px;' /></br></br>  <input id='location' name='location' required='required' type='text'  placeholder='Location' style='font-size:10pt;height:25px;width:250px;' /></br></br><input id='desc' name='desc' required='required' type='text'  placeholder='Description' style='font-size:10pt;height:25px;width:250px;' /></br></br><input id='latitude' name='latitude' required='required' type='text'  placeholder='Latitude' style='font-size:10pt;height:25px;width:250px;' /></br></br><input id='longitude' name='longitude' required='required' type='text'  placeholder='Longitude' style='font-size:10pt;height:25px;width:250px;' /></br></br><input type='submit' id='img_add' value='Upload'/>"
		document.getElementById("addplace").innerHTML=addstr2;
		
		document.getElementById("addplace").style.visibility ='visible';
		document.getElementById("image_table").style.visibility ='hidden';
		document.getElementById("divimg").style.visibility ='hidden';
		document.getElementById("sugg_table").style.visibility ='hidden';
		document.getElementById("seesugg").style.visibility ='hidden';
	}
	
	
	
	
	function seesugg()
	{
		
		addstr3=document.getElementById("seesugg").innerHTML;
		addstr3 = addstr3+"</br></br><input  name='sname' required='required' type='text'  placeholder='Place Name' style='font-size:10pt;height:25px;width:250px;' /></br></br>  <input  name='slocation' required='required' type='text'  placeholder='Location' style='font-size:10pt;height:25px;width:250px;' /></br></br><textarea name='sdesc' id='sdesc' placeholder='Description' style='text-align: left;vertical-align: top;font-family:sans-serif;font-size:10pt;height:100px;width:250px'></textarea></br></br><input id='slatitude' name='slatitude' required='required' type='text'  placeholder='Latitude' style='font-size:10pt;height:25px;width:250px;' /></br></br><input id='slongitude' name='slongitude' required='required' type='text'  placeholder='Longitude' style='font-size:10pt;height:25px;width:250px;' /></br></br><input type='submit' id='img_add' value='Upload'/>"
		document.getElementById("seesugg").innerHTML=addstr3;
		
		document.getElementById("sugg_table").style.visibility ='visible';
		document.getElementById("seesugg").style.visibility ='visible';
		document.getElementById("addplace").style.visibility ='hidden';
		document.getElementById("image_table").style.visibility ='hidden';
		document.getElementById("divimg").style.visibility ='hidden';
		
	}
	
	
	function updateplace()
	{
		
		
		$str=document.getElementById("fsp").innerHTML;
		
		addstr = ""+$str+"</td></br></br></br>  <input id='UpdatedName' name='UpdatedName' required='required' type='text'  placeholder='Updated Name' style='font-size:10pt;height:25px;width:250px;' /></br></br></br><textarea name='Updateddesc' id='Updateddesc' placeholder='Updated Description' style='text-align: left;vertical-align: top;font-family:sans-serif;font-size:10pt;height:100px;width:250px'></textarea></br></br></br><input type='submit' id='' value='Update'/> "
		document.getElementById("updateplace").innerHTML=addstr;
		
		
		document.getElementById("updateplace").style.visibility ='visible';
		document.getElementById("sugg_table").style.visibility ='hidden';
		document.getElementById("seesugg").style.visibility ='hidden';
		document.getElementById("addplace").style.visibility ='hidden';
		document.getElementById("image_table").style.visibility ='hidden';
		document.getElementById("divimg").style.visibility ='hidden';
		
	}
	
	
	
	
	
	function emptytable()
	{
		
		location.href = "table_empty.php";
	}
	

	
		function logout()
	{

		location.href = "stopsession.php";

	}

</script>
