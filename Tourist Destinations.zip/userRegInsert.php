<?php

session_start();


	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$pass = md5($_POST['pass']);
	
	
	mkdir($email, 0700);
	
	
$conn = mysqli_connect("localhost", "root", "", "project");
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


	$sql = "INSERT INTO user_info VALUES ('".$fname."', '".$lname."', '".$email."', '".$phone."', '".$pass."' ,  111);";
	
	
	//echo $sql;
	
	if (mysqli_query($conn, $sql)) {
		echo "New records inserted successfully";
		$_SESSION["regchk"]=true;
		header("Location:login.php");
	} else {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}


mysqli_close($conn);



?>