
<!DOCTYPE html>
<link rel="stylesheet" type="text/css" href="headerstyle.css"/>
<?php 
	session_start();
	require("mysql-to-json.php"); 
?>

<head>
	<title>Tourist Destinations of Bangladesh</title> 

	
</head>

<body>
<header><h1 style="float:center ;margin-left: 200px">Tourist Destinations of Bangladesh<span style="float:right; margin-right: 50px"><input type="button" class="button" onclick="login()" value="Login"> &nbsp <input type="button" class="button" name="reg" onclick="reg()" value="Registration"/> </span></h1><br> </header>

<?php


$_SESSION['passreset']=false;


if(isset($_SESSION["emailvalid"]))
{
	if($_SESSION["emailvalid"]==true)
	{
		$code=$_POST["SecurityCode"];
		
		$uemail=$_SESSION["resetemail"];
		
		$jsonData= getJSONFromDB("select resetPass from user_info where email='".$uemail."';");

			$jsn=json_decode($jsonData,true);
		
			$cofromdb=$jsn[0]["resetPass"];
			$_SESSION["tr"]=false;
			
			if($cofromdb==$code)
			{
			?>
			<form action="resetPassafterValidation.php" method="post">
			<pre>


			New Password  		: <input id="rpass" name="rpass" required="required" title="Password must contain at least 8 characters, including UPPER,Lowercase,Number and a special character @/#/%/*" type="password" required pattern="(?=.*[A-Za-z])(?=.*[0-9]).{8,}" class="ui-input" placeholder="Password" onkeyup="passlengthchk()"  onchange="form.confpass.pattern = this.value;" style="font-size:12pt;height:30px;width:300px;" /> &nbsp &nbsp <span id="sidemsg"></span></br></br></br>							

			Confirm New Password    : <input id="rconfpass" title="Please enter the same Password as above"  name="rconfpass" required="required"  required pattern="(?=.*[A-Za-z])(?=.*[0-9]).{8,}" type="password" class="ui-input" placeholder="Confirm Password" onkeyup="confrpass()" style="font-size:12pt;height:30px;width:300px;" /> &nbsp &nbsp <span id="sidemsg2"></span></br></br></br>								
			
									<input type="submit" value="submit"/>
			
			</pre>
			</form>
			

			<?php
			
			}
			
			
			else
			{
				
				$_SESSION['passreset']=true;
				header("Location:redirect.php");
		
			}
	}

}

?>












<script type="text/javascript">



function passlengthchk()
{
	//l=document.myform.pass.value.length;
	v=document.getElementById("pass").value.length;
	
	ct=0;
	nt=0;
	
	
	cap=document.getElementById("pass").value;
	
	for(i=0;i<v;i++)
	{
		if((cap[i]>='A' && cap[i]<='Z') || (cap[i]>='a' && cap[i]<='z') )
		{
			ct=1;
			break;
		}
	}
	
		
	for(i=0;i<v;i++)
	{
		if(cap[i]>='1' && cap[i]<='9')
		{
			nt=1;
			break;
		}
	}
	

	
	
	if(v>=8 )
	{
		if(ct==1 &&  nt==1)
		{
			document.getElementById("sidemsg").innerHTML="OK";
			document.getElementById("sidemsg").style.color="green";
		}
		else
		{
			document.getElementById("sidemsg").innerHTML="Character And Number Required";
			document.getElementById("sidemsg").style.color="red";
		}
		
	}
	
	
	else
	{
		document.getElementById("sidemsg").innerHTML="must be atleast 8 chararcter";
		document.getElementById("sidemsg").style.color="red";
	}
	
	
	
}


function confrpass()
{
	
	pa=document.getElementById("pass").value;
	con=document.getElementById("confpass").value;
	
	
	
	if(pa==con)
	{
		document.getElementById("sidemsg2").innerHTML="matched";
		document.getElementById("sidemsg2").style.color="green";
	}
	
	else
	{
		document.getElementById("sidemsg2").innerHTML="Password do not match";
		document.getElementById("sidemsg2").style.color="red";
	}
}






</script>





</body>