<?php

echo dltpic($_GET['imgurl']);



function dltpic($v){
	$conn = mysqli_connect("localhost", "root", "","project");
	$sql = "Delete FROM user_image where image_url='".$v."'";
	$result = mysqli_query($conn, $sql)or die(mysqli_error());
	$c=0;
	header("Location:removepicture.php");
	mysqli_close($conn);
	
}

?>