<?php require("mysql-to-json.php"); ?>
<html>
<link rel="stylesheet" type="text/css" href="headerstyle.css"/>
<head>




<style>

.button2 {
    position: relative;
    background-color: #4CAF50;
    border: none;
    font-size: 28px;
    color: #FFFFFF;
    
    text-align: center;
    -webkit-transition-duration: 0.4s; /* Safari */
    transition-duration: 0.4s;
    text-decoration: none;
    overflow: hidden;
    cursor: pointer;
}

.button2:after {
    content: "";
    background: #f1f1f1;
    display: block;
    position: absolute;
    padding-top: 300%;
    padding-left: 350%;
    margin-left: -20px !important;
    margin-top: -120%;
    opacity: 0;
    transition: all 0.8s
}

.button2:active:after {
    padding: 0;
    margin: 0;
    opacity: 1;
    transition: 0s
}





</style>
</head>












<body onload="des()">





<header><h1 style="float:center ; margin-left:180px">Tourist Destinations of Bangladesh<span style="float:right ; margin-right:50px"><input type="button" class="button" onclick="login()" value="Login"> &nbsp <input type="button" class="button" name="reg" onclick="reg()" value="Registration"/> &nbsp &nbsp &nbsp &nbsp </span></h1><br> </header>
<nav>  <ul>  <img src=photo/maxresdefault.jpg width="750" height="500" title="coxbazar" alt="Sea beach" /></ul></nav></br>
<nav>  <ul></ul></nav>
<form name ="myform" action="userRegInsert.php"  method="post">
<nav>  <ul>		
		</br><input id="fname" name="fname" required="required" type="text" class="ui-input" onkeyup="des()" placeholder="First Name" style="font-size:12pt;height:30px;width:250px;float: Left" /></br></br></br>							
			
			<input id="lname" name="lname" required="required" type="text" class="ui-input" onkeyup="des()" placeholder="LastName" style="font-size:12pt;height:30px;width:250px;float: Left" /></br></br></br>								

			<input id="email" name="email" required="required" type="email" class="ui-input" onkeyup="showHint()"" placeholder="Email" style="font-size:12pt;height:30px;width:250px;float: Left" /> &nbsp &nbsp <span id="emsg"></span> </br></br></br> 								
			
			<input id="phone" name="phone" required="required" type="text" class="ui-input" onkeyup="des()" placeholder="Phone" style="font-size:12pt;height:30px;width:250px;float: Left" /> </br></br></br>								

			<input id="pass" name="pass" required="required" title="Password must contain at least 8 characters, including UPPER,Lowercase,Number and a special character @/#/%/*" type="password" required pattern="(?=.*[A-Za-z])(?=.*[0-9]).{8,}" class="ui-input" placeholder="Password" onkeyup="passlengthchk()"  onchange="form.confpass.pattern = this.value;" style="font-size:12pt;height:30px;width:250px;float: Left" /> &nbsp &nbsp <span id="sidemsg"></span></br></br></br>							

			<input id="confpass" title="Please enter the same Password as above"  name="confpass" required="required"  required pattern="(?=.*[A-Za-z])(?=.*[0-9]).{8,}" type="password" class="ui-input" placeholder="Confirm Password" onkeyup="confrpass()" style="font-size:12pt;height:30px;width:250px;float: Left" /> &nbsp &nbsp <span id="sidemsg2"></span></br></br></br>								
			
			<input id="signup" name="signup" type="submit" class="button2"  value="Sign Up" style="color:white;font-size:12pt;height:35px;width:90;float: Left" /> </br></br>								
			
			
			
</ul></nav>

</form>
</body>






<script type="text/javascript">



function login()
{
	location.href = "login.php";

}




function reg()
{
	location.href = "registration.php";

}

function des()
{
	if(document.getElementById("fname").value!="" && document.getElementById("lname").value!="" && document.getElementById("email").value!="" && document.getElementById("phone").value!="" )
	{
		document.getElementById("signup").disabled = false;
		document.getElementById("signup").style.color= "white";
		
	}
	
	else
	{
		document.getElementById("signup").disabled = true;
		document.getElementById("signup").style.color= "gray";
	}
	
}



function passlengthchk()
{
	//l=document.myform.pass.value.length;
	v=document.getElementById("pass").value.length;
	
	ct=0;
	nt=0;
	
	
	cap=document.getElementById("pass").value;
	
	for(i=0;i<v;i++)
	{
		if((cap[i]>='A' && cap[i]<='Z') || (cap[i]>='a' && cap[i]<='z') )
		{
			ct=1;
			break;
		}
	}
	
		
	for(i=0;i<v;i++)
	{
		if(cap[i]>='1' && cap[i]<='9')
		{
			nt=1;
			break;
		}
	}
	

	
	
	if(v>=8 )
	{
		if(ct==1 &&  nt==1)
		{
			document.getElementById("sidemsg").innerHTML="OK";
			document.getElementById("sidemsg").style.color="green";
		}
		else
		{
			document.getElementById("sidemsg").innerHTML="Character And Number Required";
			document.getElementById("sidemsg").style.color="red";
		}
		
	}
	
	
	else
	{
		document.getElementById("sidemsg").innerHTML="must be atleast 8 chararcter";
		document.getElementById("sidemsg").style.color="red";
	}
	
	
	
}


function confrpass()
{
	
	pa=document.getElementById("pass").value;
	con=document.getElementById("confpass").value;
	
	
	
	if(pa==con)
	{
		document.getElementById("sidemsg2").innerHTML="matched";
		document.getElementById("sidemsg2").style.color="green";
	}
	
	else
	{
		document.getElementById("sidemsg2").innerHTML="Password do not match";
		document.getElementById("sidemsg2").style.color="red";
	}
}






function showHint() {
	str=document.getElementById('email').value;
	
	
	var xmlhttp = new XMLHttpRequest();
	t=0;
	
	xmlhttp.onreadystatechange = function() {
		
		
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) 
		{
			resp=JSON.parse(xmlhttp.responseText);
			
			for(i=0;i<resp.length;i++){
				resp[i].email;
				t=1;
			}
			
			
		}
		
		if(t==1)
		{
			document.getElementById("emsg").innerHTML = "email already exist";
			document.getElementById("emsg").style.color="red";
			document.getElementById("signup").disabled = true;
			document.getElementById("signup").style.color= "gray";
		}
		
		else
		{	
			document.getElementById("emsg").innerHTML = "OK";
			document.getElementById("emsg").style.color="green";
			
		}
			
			
	};
	var url="regJson.php?signal=readjson&email="+str;
	//alert(url);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
}


</script>

</html>