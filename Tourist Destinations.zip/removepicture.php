<html>
<?php require("mysql-to-json.php"); ?>
<head>
<title>Tourist Destinations of Bangladesh</title> 
 
<style>


  #tableContainer-1 {
    height: 100%;
    width: 100%;
    display: table;
  }
  #tableContainer-2 {
    vertical-align: middle;
    display: table-cell;
    height: 100%;
  }
  
  #desc {
    vertical-align: middle;
    margin-left:30px;
	margin-right:30px;
	color:black;
    }
  
  #myTable {
    margin: 0 auto;
  }


#wgtmsr{
 width:150px;
hight: 100px 
}
</style>

</head>



<body>
<link rel="stylesheet" type="text/css" href="headerstyle.css"/>
<header>
<span style="float:center"><h1 style="float:center;margin-left:150px">Tourist Destinations of Bangladesh <?php
	session_start();
	
		
		
		$_SESSION["picup"]=false;
	if (isset($_SESSION['loginchk']))
	{
	
		if($_SESSION['loginchk']==true)
		{
			$_SESSION["picup"]=true;
			?>
			
			
			
			<span style="float:right"><input type="button" class="button" onclick="logout()" value="Logout">&nbsp &nbsp &nbsp &nbsp
			
			
			</h1>
			<h3 style="float:center" onclick="redirect()">Home</h3>
			
			<h3 style="float:center">Welcome <?php 
			
			if(isset($_SESSION["uemail"])){
			$user=$_SESSION["uemail"];

			}		
			
			

			$jsonData= getJSONFromDB("select * from user_info");

			$jsn=json_decode($jsonData,true);
		
			for ($i=0;$i<sizeof($jsn);$i++)
			{
				if($jsn[$i]["email"]==$user)
				{
					echo $jsn[$i]["firstName"]." ".$jsn[$i]["lastName"];
				}
			}
			?>
			
			</h3>
			
			</br><select style="float:center" onchange="changeFunc(value);">
				<option>Select</option>
			  <option value="New_Picture_Upload" onclick="newpicup()">New Picture Upload</option>
			  <option value="Show_My_Picture" onclick="showpic()">Show My Picture</option>
			  <option value="Remove_Picture" onclick="removepic()">Remove Picture</option>
			  <option value="Suggest_Admin" onclick="suggestadmin()">Suggest Admin to add any New Places and Image</option>
			</select> </br></br></span>
			<?php
			
		}
		else
		{	
		
		
		header("Location:login.php");
		}
	}
	else
	{
		
		header("Location:login.php");
	}
	
	?> 
	
	</header>
	
	
	
	
	
	
	
	
	<?php
	
	
	
	
			echo "<br><h1 style='text-align:center'>To Remove Any Picture Click On That Picture</h1>";
			
			
	
	
	
	
		$usimage='select * from user_image where user_email="'.$user.'";';
		
		$imguser= getJSONFromDB($usimage);
		$iu=json_decode($imguser,true);
		$str="</br><tr>";
		$j=0;
		
		for ($i=0;$i<sizeof($iu);$i++)
		{
			$imgurl=$iu[$i]["image_url"];
			$caption=$iu[$i]["caption"];
			$lid=$iu[$i]["locationID"];
			
			$locdata= getJSONFromDB("select * from places where locationID=".$lid.";");
			$ljson=json_decode($locdata,true);
			$lname=$ljson[0]["name"];
			
			if($j==3)
			{
				$str=$str."</tr><tr>";
				
				$j=0;
			}
			
			$str=$str." <td><img src='".$imgurl."'width='400' height='250' value='".$imgurl."'  onclick='imgremove(this)' style='float: center;margin-left:20px;margin-top:20px'/></td> ";
			$j++;
			
		}

			
			echo "<div id='tableContainer-1'>  <div id='tableContainer-2'>    <table id='myTable' >".$str."</tr></table></div>  </br></br></div></div></br></br>";
			

?>
	
	
	

	
	</body>
</html>	
	
	
	
	
	
	
	
	
	
	
	
	<script type="text/javascript">


function logout()
{

	location.href = "stopsession.php";

}

function redirect()
{
	location.href = "index.php";
}


function changeFunc($i)
{
	
	
	if($i=="New_Picture_Upload")
	{
		//alert("ture");
		<?php
		$_SESSION["loginchk"]=true;
		?>
		location.href = "newpicupload.php";
	}
	
	else if($i=="Show_My_Picture")
	{
		//alert("ture");
		<?php
		$_SESSION["loginchk"]=true;
		?>
		location.href = "showmypicture.php";
	}
	
	
	else if($i=="Suggest_Admin")
	{
		//alert("ture");
		<?php
		$_SESSION["loginchk"]=true;
		?>
		location.href = "suggestplaces.php";
	}
	
}

function imgremove(element)
{
	imgurl=element.getAttribute("value");
	//alert(imgurl);
	
	var xmlhttp = new XMLHttpRequest();
	if (confirm("Are You Sure?") == true) {
	var url="forRemovepicture.php?imgurl="+imgurl;
	//alert(url);
	xmlhttp.open("GET", url, true);
	xmlhttp.send();
	
	}
	location:index.php;
}

</script>