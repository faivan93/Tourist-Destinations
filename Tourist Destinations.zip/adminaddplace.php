<?php
require("mysql-to-json.php"); 
session_start();

$_SESSION["plcadd"]=false;

if (isset($_SESSION['loginchk']))
	{
		if($_SESSION['loginchk']==true)
		{
			
			$name=$_POST["name"];
			$location=$_POST["location"];
			$description=$_POST["desc"];
			$latitude=$_POST["latitude"];
			$longitude=$_POST["longitude"];
			
			
			$conn = mysqli_connect("localhost", "root", "","project");
			
			$sql='insert into places(name,location,description,latitude,longitude) values("'.$name.'" , "'.$location.'" , "'.$description.'" ,'.$latitude.' ,'.$longitude.')';
			echo $sql;
			
			$result = mysqli_query($conn, $sql)or die(mysqli_error());

			
				$_SESSION["plcadd"]=true;
				header("Location:admin.php");
			
			
		}
		else
		{	
		echo "<h1 style='text-align:center'>You are To Login First</h1></br></br>";
		
		header("Location:login.php");
		}
	}
	else
	{
		echo "<h1 style='text-align:center'>You Need To Login First</h1></br></br>";
		header("Location:login.php");
	}

?>