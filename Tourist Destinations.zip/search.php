<?php

$svalue=$_POST["search"];
require("mysql-to-json.php");
?>

<!DOCTYPE html>
<html>
<link rel="stylesheet" type="text/css" href="headerstyle.css"/>

<head>

<title>Tourist Destinations of Bangladesh</title> 




<style>


  #tableContainer-1 {
    height: 100%;
    width: 100%;
    display: table;
  }
  #tableContainer-2 {
    vertical-align: middle;
    display: table-cell;
    height: 100%;
  }
  
  #desc {
    vertical-align: middle;
    margin-left:30px;
	margin-right:30px;
	color:black;
    }
  
  #myTable {
    margin: 0 auto;
  }


</style>



</head>


<body>



<header>

	<span style="float:center;"><h1 style="float:center;margin-left: 180px">Tourist Destinations of Bangladesh <?php
	session_start();
	
		

	if (isset($_SESSION['regchk']))
	{
	
		if($_SESSION['regchk']==true)
		{
			$_SESSION["loginchk"]=true;
			?>
			
			
			<input type="button" class="button" onclick="logout()" style="float:right ; margin-right: 50px" value="Logout">
			
			
			</h1>
			<h3 style="float:center">Welcome <?php 
			
			if(isset($_SESSION["uemail"])){
			$user=$_SESSION["uemail"];

			}
			
			
			

			$jsonData= getJSONFromDB("select * from user_info");

			$jsn=json_decode($jsonData,true);
		
			for ($i=0;$i<sizeof($jsn);$i++)
			{
				if($jsn[$i]["email"]==$user)
				{
					echo $jsn[$i]["firstName"]." ".$jsn[$i]["lastName"];
				}
			}
			?>
			</br></br><select style="float:center ;" id="selectBox"  name="selectBox" onchange="changeFunc(value);">
				<option>Select</option>
			  <option value="New_Picture_Upload">New Picture Upload</option>
			  <option value="Show_My_Picture">Show My Picture</option>
			  <option value="Remove_Picture">Remove Picture</option>
			  <option value="Suggest_Admin">Suggest Admin to add any New Places and Image</option>
			</select> </br></br>
			<?php
			
		}
		else
		{
		?>
			<span style="float:right; margin-right: 50px"><input type="button" class="button" onclick="login()"  value="Login"> &nbsp <input type="button" class="button" name="reg" onclick="reg()" value="Registration"/></span>
		<?php
		}
	}
	else
	{
		?>
			<span style="float:right;margin-right: 50px"><input type="button" class="button" onclick="login()" value="Login"> &nbsp <input type="button" class="button" name="reg" onclick="reg()" value="Registration"/> </span>
		<?php
	}
	?>  
		
	</br></br></span>
</header>




<?php


		

		

		$jsonData= getJSONFromDB('select keywID from keyword where keyword="'.$svalue.'";' );

		$jsn=json_decode($jsonData,true);
			
			$keyID=$jsn[0]["keywID"];


		$jsonData2= getJSONFromDB('select imageId from image_keyword where keywID='.$keyID.';' );
		

		$jsn2=json_decode($jsonData2,true);
		
			$str="";
			
			
			
			for($i=0;$i<sizeof($jsn2);$i++){
				
				$jsonData3= getJSONFromDB('select imgURL from places_image where imageId='.$jsn2[$i]["imageId"].';' );

				$jsn3=json_decode($jsonData3,true);

				$imgURL=$jsn3[0]["imgURL"];
				
				
				$str=$str."<tr> <td><img type='submit' src='".$imgURL."'width='900' height='500' onclick='imgurl(".$jsn2[$i]["imageId"].")' style='float: center'/></td></tr>";
			
			}
			
			 
		echo "<div id='tableContainer-1'>  <div id='tableContainer-2'>    <table id='myTable' >".$str."</table>  </br></br></div></div></br></br>";

		
		//header("Location:imgplaceshow.php");


?>





</body>


</html>





<script type="text/javascript">

function login()
{
	location.href = "login.php";

}

function reg()
{
	location.href = "registration.php";

}

function logout()
{

	location.href = "stopsession.php";

}

function reg()
{
	location.href = "registration.php";

}


function imgurl(i)
{

	
window.location.href="imgplaceshow.php?imgID="+i;
	
}



</script>
