<!DOCTYPE html>
<html>
<?php require("mysql-to-json.php"); ?>
<head>
	<title>Login verification</title>
</head>
<body align=center>
	<?php
		session_start();
		$user=$_POST["lemail"];
		$enpass=$_POST["lpass"];
		$r=0;
		$s=0;
		$pass=md5($enpass);
		
		//Get data from database
		

		$jsonData= getJSONFromDB("select * from user_info");

		$jsn=json_decode($jsonData,true);
		
		print_r($jsn);
		
		for ($i=0;$i<sizeof($jsn);$i++)
		{
			
			if($jsn[$i]["email"]==$user && $jsn[$i]["password"]==$pass && $jsn[$i]["privilige"]==957)
			{
				$s=1;
				break;
			}
			
			else
			{
				if($jsn[$i]["email"]==$user && $jsn[$i]["password"]==$pass && $jsn[$i]["privilige"]==111)
				{
					$r=1;
					break;
				}
				
			}
		}
		
		
		if($s==1)
		{
			$_SESSION['regchk']=true;
			header("Location: admin.php");
			$_SESSION["adminemail"]=$user;
			
		}
		
		else if ($r==1)
		{
			$_SESSION['regchk']=true;
			$_SESSION['loginchk']=true;
			$_SESSION["uemail"]=$user;
			header("Location: index.php");
			
		}
		else
		{
			$_SESSION['regchk']=false;
			$_SESSION['loginchk']=false;
			header("Location: login.php");
		}
	?>
</body>
</html>