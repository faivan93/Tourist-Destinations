<?php

require("mysql-to-json.php");
session_start();

$_SESSION['picup']=false;

if (isset($_SESSION['loginchk']))
	{
	
		if($_SESSION['loginchk']==true)
		{
			$_SESSION['picup']=true;

			$_SESSION["addimgup"]=false;

			$imgid=$_POST["addimgid"];
			$name=$_POST["wgtmsr"];
			$imgurl=$_FILES["fileToUpload"]["name"];

			$conn = mysqli_connect("localhost", "root", "","project");
			if (!$conn) {
				die("Connection failed: " . mysqli_connect_error());
			}


			$target_Path = "photo/".$imgurl;
			$target_tmp =  $_FILES["fileToUpload"]["tmp_name"] ;


			$target_dir = "photo/";
			$target_file = $target_dir . $_FILES["fileToUpload"]["name"];
			//echo $_FILES["fileToUpload"]["name"]."<br>";
			$uploadOk = 1;
			// Check if image file is a actual image or fake image

			if (file_exists($target_file)) {
				echo "Sorry, file already exists<br>";
				$uploadOk = 0;
			}
			if ($_FILES["fileToUpload"]["size"] > 5000000) {
				echo "File size exceeded<br>";
				$uploadOk = 0;
			}
			if ($uploadOk == 0) {
				echo "Sorry, your file was not uploaded<br>";
			}
			else{

			
				$locdata= getJSONFromDB("select `locationID` from places where `name`='".$name."';");
				
				$ljson=json_decode($locdata,true);
				$lID=$ljson[0]["locationID"];
				echo $lID;



			if(move_uploaded_file( $target_tmp, $target_file)) 
			{
				$sql="insert into places_image values(".$imgid.",".$lID.",'".$target_file."');";
				
				$result =mysqli_query($conn, $sql)or die(mysqli_error());
			   // echo "The file ".  $_FILES["fileToUpload"]["name"]. " has been uploaded<br>";
				
				$_SESSION["addimgup"]=true;
				header("Location:admin.php");
				
			}
			else 
			{
				$_SESSION["addimgup"]=false;
				header("Location:admin.php");
				echo "Sorry, there was an error uploading your file<br>";
			}

			}

		}
		else
		{	
				
		header("Location:login.php");
		}
		
		
}

		else
		{
		header("Location:login.php");
		}


?>