<!DOCTYPE html>
<link rel="stylesheet" type="text/css" href="headerstyle.css"/>
<head>
	<title>Tourist Destinations of Bangladesh</title> 

	
</head>

<body>

<header><h1 style="float:center ;margin-left: 200px">Tourist Destinations of Bangladesh<span style="float:right; margin-right: 50px"><input type="button" class="button" onclick="login()" value="Login"> &nbsp <input type="button" class="button" name="reg" onclick="reg()" value="Registration"/> </span></h1><br> </header>


<?php

session_start();

$email=$_POST["email"];
$p=0;
$_SESSION["resetemail"]=$email;
require("mysql-to-json.php");


	if(isset($_SESSION["tr"]))
	{
		if($_SESSION["tr"]==true)
		{
			$email=$_SESSION["resetemail"];
			$_SESSION["tr"]==0;
			$p=1;
		}
	}

		$jsonData= getJSONFromDB("select email from user_info");

			$jsn=json_decode($jsonData,true);
		
			for ($i=0;$i<sizeof($jsn);$i++)
			{
				if($jsn[$i]["email"]==$email)
				{
					$_SESSION["resetemail"]=$email;
					$_SESSION["emailvalid"]=true;
					$p=1;					
				}
			}
			
			
			
			
			if($p==1)
			{
				$rnd=rand(100000,999999);
				
				$conn = mysqli_connect("localhost", "root", "","project");
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}
				
				$sql="UPDATE user_info SET resetPass='".$rnd."' where email='".$email."';";
				$result =mysqli_query($conn, $sql)or die(mysqli_error());
				$_SESSION["emailvalid"]=true;
				
				?>
				<pre>
				<form action="checksecuritycode.php" method="post">
				
					<h4 style="text-align:center; color:red">A security code will send to your email. Please insert that code for reset your password.</h4>

					<input type="rext" name="SecurityCode" required="required" class="ui-input" placeholder="Security Code" style="font-size:15px;height:30px;width:300px;float:center"/></br>
					
								<input type="submit" value="Submit"/></br>
					
				
				</form>
				</pre>
				
				<?php
				$p=1;
			}
			else
			{	
				$p=0;
				header("Location:resetPass.php");
				
			}
			
			
			if(isset($_SESSION['passreset']))
				{
					if($_SESSION['passreset']==false)
					{
								echo "</br><h4 style='text-align:center;color:red'>Your entered incorrect security code</h4> </br>";
					}
				}



?>

<body>