<html>
<?php require("mysql-to-json.php"); ?>
<head>
<title>Tourist Destinations of Bangladesh</title> 

<style>
#wgtmsr{
 width:200px;
hight: 100px;
font-size: 15px;
}
</style>

</head>



<body>
<link rel="stylesheet" type="text/css" href="headerstyle.css"/>
<header>
	<span style="float:center"><h1 style="float:center">Tourist Destinations of Bangladesh <?php
	session_start();
	
		
		
		$_SESSION["picup"]=false;
	if (isset($_SESSION['loginchk']))
	{
	
		if($_SESSION['loginchk']==true)
		{
			$_SESSION["picup"]=true;
			?>
			
			
			
			<span style="float:right"><input type="button" class="button" onclick="logout()" value="Logout">&nbsp &nbsp &nbsp &nbsp
			
			
			</h1>
			<h3 style="float:center" onclick="redirect()">Home</h3>
			
			<h3 style="float:center">Welcome <?php 
			
			if(isset($_SESSION["uemail"])){
			$user=$_SESSION["uemail"];

			}		
			
			

			$jsonData= getJSONFromDB("select * from user_info");

			$jsn=json_decode($jsonData,true);
		
			for ($i=0;$i<sizeof($jsn);$i++)
			{
				if($jsn[$i]["email"]==$user)
				{
					echo $jsn[$i]["firstName"]." ".$jsn[$i]["lastName"];
				}
			}
			?>
			
			</h3>
			
			</br><select style="float:center" onchange="changeFunc(value);">
				<option>Select</option>
			  <option value="New_Picture_Upload" >New Picture Upload</option>
			  <option value="Show_My_Picture" >Show My Picture</option>
			  <option value="Remove_Picture" >Remove Picture</option>
			  <option value="Suggest_Admin" >Suggest Admin to add any New Places and Image</option>
			</select> </br></br>
			<?php
			
		}
		else
		{	
		echo "<h1 style='text-align:center'>You are To Login First</h1></br></br>";
		
		header("Location:login.php");
		}
	}
	else
	{
		echo "<h1 style='text-align:center'>You Need To Login First</h1></br></br>";
		header("Location:login.php");
	}
	
	?>  
	</br></span>
</header>

<br /><br />
<h3 align=center>Suggest Place</h3>
<pre align=center>
	<form action="suggestDB.php" method="POST" id="suggform">
	Name: 	     <input type="text" name="sname" /><br />
	Location:    <input type="text" name="sloc" /><br />
	Description: <textarea name="sdes" rows="4" cols="50"></textarea><br />
	Latitude:    <input type="text" name="slat" /><br />
	Longitude:   <input type="text" name="slong" /><br />
	<input type="submit" value="Submit" />
	</form>
</pre>
<script type="text/javascript">


function logout()
{

	location.href = "stopsession.php";

}

function redirect()
{
	location.href = "index.php";
}

function changeFunc($i)
{
	if($i=="New_Picture_Upload")
	{
		//alert("ture");
		<?php
		$_SESSION["loginchk"]=true;
		?>
		location.href = "newpicupload.php";
	}
	
	else if($i=="Show_My_Picture")
	{
		//alert("ture");
		<?php
		$_SESSION["loginchk"]=true;
		?>
		location.href = "showmypicture.php";
	}
	
	else if($i=="Remove_Picture")
	{
		//alert("ture");
		<?php
		$_SESSION["loginchk"]=true;
		?>
		location.href = "removepicture.php";
	}
	
	else if($i=="Suggest_Admin")
	{
		//alert("ture");
		<?php
		$_SESSION["loginchk"]=true;
		?>
		location.href = "suggestplaces.php";
	}
}


</script>