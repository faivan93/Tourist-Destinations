<!DOCTYPE html>
<link rel="stylesheet" type="text/css" href="headerstyle.css"/>
<?php require("mysql-to-json.php"); ?>
<head>
	<title>Tourist Destinations of Bangladesh</title> 

	
</head>
<body>
<header><h1 style="float:center ;margin-left: 200px">Tourist Destinations of Bangladesh<span style="float:right; margin-right: 50px"><input type="button" class="button" onclick="login()" value="Login"> &nbsp <input type="button" class="button" name="reg" onclick="reg()" value="Registration"/> </span></h1><br> </header>

<?php
session_start();

if (isset($_SESSION['regchk']))
{
	if($_SESSION['regchk']==true)
	{
		echo "<h1 style='text-align:center'>Registration Successfull</h1>";
	}
	else
	{
		echo "<h1 style='text-align:center'>Wrong login credentials</h1>";
	}
}

else if (isset($_SESSION['picup']))
{
	if($_SESSION['picup']==false)
	{
		echo "<h1 style='text-align:center'>You Need To Login First</h1>";
	}
}


			if(isset($_SESSION["passcngreset"]))
			{
				if($_SESSION["passcngreset"]==true)
				{
					echo "<h4 style='text-align:center'>Password Reset Successfully</h4></br>";
				}
			}


?>

<nav>  </br></br></br></br><ul> <span style="color:red">To view your uploaded photo and account details, please login to your account. </span> &nbsp &nbsp &nbsp &nbsp </ul></nav></br>



<form action="checker.php" method="POST">
<nav>  <ul>		
		</br><input id="lemail" name="lemail" required="required" type="email" class="ui-input" placeholder="Email" style="font-size:13pt;height:30px;width:250px;float: Left" /></br></br></br>							
			
			<input id="lpass" name="lpass" required="required" type="password" class="ui-input" placeholder="Password" style="font-size:13pt;height:30px;width:250px;float: Left" /></br></br></br>								
			
			<input id="login" name="login" type="submit" class="button2"  value="Login" style="color:white;font-size:12pt;height:37px;width:180px;float: Left"  onclick=check() /> </br></br></br>								

			<a href="resetPass.php" id="emsg">Forgot Password?</a>
			
			
</ul></nav>
</form>



<script style="text/javascript">
function login()
{
	location.href = "login.php";

}

function reg()
{
	location.href = "registration.php";
}
</script>
</body>
</html>