<?php

function getData($sql){
	$conn = mysqli_connect("localhost", "root", "","project");
	
	//echo $sql;
	$result = mysqli_query($conn, $sql)or die(mysqli_error());
	$arr=array();
	while($row = mysqli_fetch_assoc($result)) {
		$arr[]=$row;
	}
	
	return json_encode($arr);
}

if($_REQUEST['signal']=="readjson"){
	$sql="select * from user_info where email='".$_REQUEST['email']."'";
	//echo $sql;
	echo getData($sql);
	
}

?>