<?php

	$conn = mysqli_connect("localhost", "root", "", "project");
	
	if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
	}


	$sql = "TRUNCATE TABLE suggested ";
	
	if (mysqli_query($conn, $sql)) 
	{
		echo "<br />Place successfully suggested to Admin<br />";
	} 
	else 
	{
		echo "<br />Unable to suggest place<br />";
	}
	
	mysqli_close($conn);
	
	header("Location:admin.php");



?>