<?php

session_start();

$_SESSION["passcngreset"]=false;
$pass=md5($_POST["rpass"]);
$email=$_SESSION["resetemail"];

	$conn = mysqli_connect("localhost", "root", "","project");
				if (!$conn) {
					die("Connection failed: " . mysqli_connect_error());
				}
				
				$sql="UPDATE user_info SET password='".$pass."' where email='".$email."';";
				$result =mysqli_query($conn, $sql)or die(mysqli_error());
				
				
				$_SESSION["passcngreset"]=true;
				
				header("Location:login.php");
	

?>