<?php

 require("mysql-to-json.php"); 
session_start();

$_SESSION["plcupdate"]=false;

if (isset($_SESSION['loginchk']))
	{
	
		if($_SESSION['loginchk']==true)
		{
			

			

			$upname=$_POST["UpdatedName"];
			$updesc=$_POST["Updateddesc"];
			$locName=$_POST["wgtmsr"];
			

			$conn = mysqli_connect("localhost", "root", "","project");
			if (!$conn) {
				die("Connection failed: " . mysqli_connect_error());
			}
			
			
			
			
		

		$jsonData= getJSONFromDB('select locationID from places where name="'.$locName.'"');

		$jsn=json_decode($jsonData,true);
			
			$locID=$jsn[0]["locationID"];
			
			//echo $locID;
			
			
			
			$sql='UPDATE places SET name="'.$upname.'" , description="'.$updesc.'" WHERE locationID='.$locID.''; 
			echo $sql;
			$result =mysqli_query($conn, $sql)or die(mysqli_error());
			
			$_SESSION["plcupdate"]=true;
			
			header("Location:admin.php");
			
			


			
			

		}
		else
		{	
				
		header("Location:login.php");
		}
		
		
}

		else
		{
		header("Location:login.php");
		}


?>