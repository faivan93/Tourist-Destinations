<!DOCTYPE html>
<html>
<?php require("mysql-to-json.php"); ?>
<link rel="stylesheet" type="text/css" href="headerstyle.css"/>

<head>

<title>Tourist Destinations of Bangladesh</title> 


</head>


<body>




<header>

	<span style="float:center;"><h1 style="float:center;margin-left: 180px">Tourist Destinations of Bangladesh <?php
	session_start();
	
		

	if (isset($_SESSION['regchk']))
	{
	
		if($_SESSION['regchk']==true)
		{
			$_SESSION["loginchk"]=true;
			?>
			
			
			<input type="button" class="button" onclick="logout()" style="float:right ; margin-right: 50px" value="Logout">
			
			
			</h1>
			<h3 style="float:center">Welcome <?php 
			
			if(isset($_SESSION["uemail"])){
			$user=$_SESSION["uemail"];

			}
			
			
			

			$jsonData= getJSONFromDB("select * from user_info");

			$jsn=json_decode($jsonData,true);
		
			for ($i=0;$i<sizeof($jsn);$i++)
			{
				if($jsn[$i]["email"]==$user)
				{
					echo $jsn[$i]["firstName"]." ".$jsn[$i]["lastName"];
				}
			}
			?>
			</br></br><select style="float:center ;" id="selectBox"  name="selectBox" onchange="changeFunc(value);">
				<option>Select</option>
			  <option value="New_Picture_Upload">New Picture Upload</option>
			  <option value="Show_My_Picture">Show My Picture</option>
			  <option value="Remove_Picture">Remove Picture</option>
			  <option value="Suggest_Admin">Suggest Admin to add any New Places and Image</option>
			</select> </br></br>
			<?php
			
		}
		else
		{
		?>
			<span style="float:right; margin-right: 50px"><input type="button" class="button" onclick="login()"  value="Login"> &nbsp <input type="button" class="button" name="reg" onclick="reg()" value="Registration"/></span>
		<?php
		}
	}
	else
	{
		?>
			<span style="float:right;margin-right: 50px"><input type="button" class="button" onclick="login()" value="Login"> &nbsp <input type="button" class="button" name="reg" onclick="reg()" value="Registration"/> </span>
		<?php
	}
	?>  
		
	</br></br></span>
</header>

  
 <form  action="search.php" method="post">
  </br></br><input  id="search" name="search" type="text" class="ui-input" placeholder="Search" style="margin-left: 50px;font-size:15px;height:35px;width:1200px;float: Left" /> &nbsp  
  <button type="submit" > <img src=photo/Gakuseisean-Ivista-2-Start-Menu-Search.ico  width="40" height="32px"/></button></br></br>
</form>

  <table border="0 px" width="100%" ID="Table1">
		
		<tr>
			<td><img src=photo/coxbazar1.jpg width="655" height="350" title="Cox's Bazar" alt="Sea beach" style="float: center"  /></td>
			<td><img src=photo/coxbazar2.jpg width="655" height="350" title="Cox's Bazar" alt="Sea beach" style="float: center"  /></td>
		</tr>
		
		
		<tr >
			<td colspan="5"><h1>  <a href="placesfromindex.php?place=Cox's Bazar"/><p style="text-align:center;float: center">Cox's Bazar</a></h1></td>
		</tr>
  
  </table>
  
  
  
  
  <table border="0 px" width="100%" ID="Table2">
		
		<tr>
			<td><img src=photo/himchori.jpg width="655" height="350" title="Him Chori" alt="Himchori"  style="float: center"  /></td>
			<td><img src=photo/himcori2.jpg width="655" height="350" title="Him Chori" alt="Himchori" style="float: center"  /></td>
		</tr>
		
		
		<tr >
			<td colspan="5"><h1>  <a href="placesfromindex.php?place=Himchori"/><p style="text-align:center;float: center">Himchori</a></h1></td>
		</tr>
  
  </table>
  
  
    <table border="0 px" width="100%" ID="Table3">
		
		<tr>
			<td><img src=photo/bandarban1.jpg width="655" height="350" title="Bandarban" alt="Bandarban"  style="float: center;"  /></td>
			<td><img src=photo/bandarban2.jpg width="655" height="350" title="Bandarban" alt="Bandarban" style="float: center"  /></td>
		</tr>
		
		
		<tr >
			<td colspan="5"><h1>  <a href="placesfromindex.php?place=Bandarban"/><p style="text-align:center;float: center">Bandarban</a></h1></td>
		</tr>
  
  </table>
  
  
  
  <table border="0 px" width="100%" ID="Table4">
		
		<tr>
			<td><img src=photo/saintmartin1.jpg width="655" height="350" title="Saint Martin" alt="Saint Martin"  style="float: center;"  /></td>
			<td><img src=photo/saintmartin2.jpg width="655" height="350" title="Saint Martin" alt="Saint Martin" style="float: center"  /></td>
		</tr>
		
		
		<tr >
			<td colspan="5"><h1>  <a href="placesfromindex.php?place=Saint Martin's Island"/><p style="text-align:center;float: center">Saint Martin's Island</a></h1></td>
		</tr>
  
  </table>
  
   <footer>
  <h4 style="float:center">Contact information : <a href="http://mail.google.com" style="front-size:10px">nadim.hq321@gmail.com</a></br>Phone : <span style="color:#FFFFFF">+8801827090222</span></h4>
</footer> 
 
</body>
</html>



<script type="text/javascript">

function login()
{
	location.href = "login.php";

}

function reg()
{
	location.href = "registration.php";

}

function logout()
{

	location.href = "stopsession.php";

}

function changeFunc($i)
{
	//alert($i);
	if($i=="New_Picture_Upload")
	{
		//alert("ture");
		<?php
		$_SESSION["loginchk"]=true;
		?>
		location.href = "newpicupload.php";
	}
	
	else if($i=="Show_My_Picture")
	{
		//alert("ture");
		<?php
		$_SESSION["loginchk"]=true;
		?>
		location.href = "showmypicture.php";
	}
	
	else if($i=="Remove_Picture")
	{
		//alert("ture");
		<?php
		$_SESSION["loginchk"]=true;
		?>
		location.href = "removepicture.php";
	}
	
	else if($i=="Suggest_Admin")
	{
		//alert("ture");
		<?php
		$_SESSION["loginchk"]=true;
		?>
		location.href = "suggestplaces.php";
	}
}

</script>