<!DOCTYPE html>
<link rel="stylesheet" type="text/css" href="headerstyle.css"/>
<?php 
	session_start();
	require("mysql-to-json.php"); 
?>

<head>
	<title>Tourist Destinations of Bangladesh</title> 

	
</head>
<body>
<header><h1 style="float:center ;margin-left: 200px">Tourist Destinations of Bangladesh<span style="float:right; margin-right: 50px"><input type="button" class="button" onclick="login()" value="Login"> &nbsp <input type="button" class="button" name="reg" onclick="reg()" value="Registration"/> </span></h1><br> </header>
	<pre>
	<form action='securityCodeValidation.php' method="post"> 
					Enter your Email 

					<input type="email" name="email" required="required" class="ui-input" placeholder="Email" style="font-size:15px;height:30px;width:300px;float:center"/></br>
					
					<input type="submit" value="Submit"/></br>
			
	</form>
	</pre>
	
	
	<?php
	if(isset($_SESSION["emailvalid"]))
	{	
		if($_SESSION["emailvalid"]==false)
		{
			echo "</br><h4 style='text-align:center;color:red'>Your Input Email Is Not Regestered</h4> </br>";
		}
	}
	

	?>	
	
</body>
						
